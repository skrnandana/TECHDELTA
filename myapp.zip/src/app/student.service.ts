import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  isUserLogged: boolean;
  favoriteItems = [];
  enrollItems=[]
  enrollToBeAdded:Subject<any>;
  eventToBeAdded: Subject<any>;
  
  
  constructor(private httpClient: HttpClient) {
    this.isUserLogged = false;
    this.eventToBeAdded = new Subject();
    this.enrollToBeAdded = new Subject();
  
   }

 setUserLoggedIn(): any { 
   this.isUserLogged = true;
 }
 setUserLoggedOut(): any { 
   this.isUserLogged = false;
 }
 getUserLogged() {
   return this.isUserLogged;
 }
 registerStudent(student: any) {
  return this.httpClient.post('RESTAPI_TechDelta/webapi/myresource/registerStudent/',  student);
 }

 getStudentbyEmail(emailId: any) {     
  return this.httpClient.get('RESTAPI_TechDelta/webapi/myresource/getStudentByEmail/' + emailId);
 }

 sendMail(email: any): any {
	return this.httpClient.get('RESTAPI_TechDelta/webapi/myresource/mail/' +email);
 } 

 getEvents() {
  return this.httpClient.get('RESTAPI_TechDelta/webapi/myresource/getEvents');
 }

 // getEvents() {
 //  return this.httpClient.get('RESTAPI_TechDelta/webapi/myresource/getEvents').pipe(retry(10));
 // }

 purchase(event: any) {
 	return this.httpClient.post('RESTAPI_TechDelta/webapi/myresource/purchase', event);
 }

 addToFavorites(event: any) {
 	this.eventToBeAdded.next(event);
 	this.favoriteItems.push(event);
 }
 addToEnroll(event: any) {
  this.enrollToBeAdded.next(event);
  this.enrollItems.push(event);
}

 getForFavorite() {
 	return this.eventToBeAdded.asObservable();
 }
 getForEnroll() {
  return this.enrollToBeAdded.asObservable();
}

}
 