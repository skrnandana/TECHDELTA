import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { StudentRegisterComponent } from './student-register/student-register.component';
import { HeaderComponent } from './header/header.component';
// import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { LoginOrganizerComponent } from './login-organizer/login-organizer.component';
import { OrganizerRegisterComponent } from './organizer-register/organizer-register.component';
import { ShowDbImagesComponent } from './show-db-images/show-db-images.component';
// import { StudentLoginComponent } from './student-login/student-login.component';
import { StudentloginComponent } from './studentlogin/studentlogin.component';
import { StudentregisterComponent } from './studentregister/studentregister.component';
import { UploadeventComponent } from './uploadevent/uploadevent.component';
import { NgForm } from '@angular/forms';
import { ShoweventsComponent } from './showevents/showevents.component';
import { FavoritesComponent } from './favorites/favorites.component';
import { EnrollComponent } from './enroll/enroll.component';
import { AboutComponent } from './about/about.component';

const appRoot: Routes = [
                        {path: 'signupO', component: OrganizerRegisterComponent},
                        {path: '', component: HomeComponent},
                      {path:'loginO', component: LoginOrganizerComponent},
                      {path: 'loginS', component: StudentloginComponent},
                      {path: 'signupS', component: StudentregisterComponent},
                    {path:'home',component:HomeComponent},
                    {path:'upload',component: UploadeventComponent},
                    {path:'show_events',component: ShoweventsComponent},
                    {path:'favorites',component: FavoritesComponent},
                    {path:'enroll',component: EnrollComponent},
                    {path:'about',component: AboutComponent}
                  ];

                    
@NgModule({
  declarations: [
    AppComponent,
    // StudentRegisterComponent,
    HeaderComponent,
    // LoginComponent,
    HomeComponent,
    LoginOrganizerComponent,
    OrganizerRegisterComponent,
    ShowDbImagesComponent,
    // StudentLoginComponent,
    StudentloginComponent,
    StudentregisterComponent,
    UploadeventComponent,
    ShoweventsComponent,
    FavoritesComponent,
    EnrollComponent,
    AboutComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, 
    HttpClientModule,
    RouterModule.forRoot(appRoot),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
