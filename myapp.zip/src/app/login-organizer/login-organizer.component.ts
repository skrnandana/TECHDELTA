import { Router } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { OrgServiceService } from './../org-service.service';
import { Component, EventEmitter, Output,OnInit } from '@angular/core';
import { ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-login-organizer',
  templateUrl: './login-organizer.component.html',
  styleUrls: ['./login-organizer.component.css']
})
export class LoginOrganizerComponent implements OnInit {
  title = 'Tech Delta';

  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;
  show: boolean;
  //auth2: gapi.auth2.GoogleAuth;
  Name: any;
  auth2: gapi.auth2.GoogleAuth;

  organizer : any;
  OrgData: any;
  orgId: any;

  constructor(private router: Router, private orgService: OrgServiceService) {
    this.organizer = {email:'', password: ''};
  }

  ngOnInit(): void {
    this.googleInitialize();
  }

  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '631867203803-gfnbuj33563dmuorhmfm6cv2prqasulq.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        this.show = true;
        this.Name =  profile.getName();
        console.log(this.Name)
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
        this.router.navigate(['upload']);
      }, (error) => {
        // alert(JSON.stringify(error, undefined, 2));
      });     
  }

  loginSubmit(loginForm : any) {
      this.orgService.getOrganizerByEmail(loginForm['email']).subscribe((result: any) => {
          console.log(result);
          this.OrgData = result.organizerId;
          if(loginForm['password'] == result['password']){
            // alert("welcome");
            this.orgService.setOrganizerLoggedIn();
            this.router.navigate(['']);
            localStorage.setItem('organizer','JSON.stringify(result)');
            // this.router.navigate(['HomeComponent']);
          }
          else{
            alert("Invalid email or password");
          } 
          localStorage.setItem('orgId', this.OrgData);

        });  
      console.log("ID", this.OrgData);
      // console.log(this.loginId);
  }

  orgsignup() {
    this.router.navigate(['signupO']);
  }
}