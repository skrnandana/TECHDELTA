import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';
declare var jQuery: any;

@Component({
  selector: 'app-studentregister',
  templateUrl: './studentregister.component.html',
  styleUrls: ['./studentregister.component.css']
})
export class StudentregisterComponent implements OnInit {

  student: any;
  signUpDetails: any;
  gender: string = '';
  genders: any = [
    'Male',
    'Female'
  ]

  constructor(private router:Router,private studservice: StudentService) { 
    this.student = {studentName: '', studentInstitute: '', currentEducation: '', gender: '', email: '' ,password: ''};
  }

  studentName: string;
  studentInstitute: string;
  currentEducation : string;
  email: any;
  password: any;
  registeredUser = false;

  ngOnInit(): void {
  }

  radioChangeHandler(event: any) {
    this.gender = event.target.value;
  }

  registerStudent(): void {
    this.studservice.registerStudent(this.student).subscribe((result: any) => { console.log(result); } );
    console.log(this.student);
    // alert("Registered");
    this.router.navigate(['loginS']);
    this.studservice.sendMail(this.student.email).subscribe();
  }
}
