import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-show-db-images',
  templateUrl: './show-db-images.component.html',
  styleUrls: ['./show-db-images.component.css']
})
export class ShowDbImagesComponent implements OnInit {

	events: any;

  constructor(private studservice: StudentService) { }

  ngOnInit(): void {
  	
  }

  

}
