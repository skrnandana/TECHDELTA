import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { OrgServiceService } from '../org-service.service'

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  public login: string;
  events = [];

  constructor(private studservice: StudentService, private orgservice: OrgServiceService) { }

  ngOnInit(): void {
    this.studservice.getForFavorite().subscribe(result => this.events.push(result));
  }

  userLogout() {
    if (this.login == "orglogin") {
    this.orgservice.setorgLoggedOut();
    }
    if (this.login == "studlogin") {
      return this.studservice.setUserLoggedOut();
    }
  }

  userVerify() {
    // return this.service.getUserLogged();
    // console.log(this.login);
    if (this.login == "orglogin") {
      return this.orgservice.getOrganizerLogged();
    }
    if (this.login == "studlogin") {
      return this.studservice.getUserLogged();
    }
    // console.log("org", this.orgservice.getOrganizerLogged());
  }

  orgsignup() {
    this.login = "orgsignup";
  }

  orglogin() {
    this.login = "orglogin";
  }

  studsignup() {
    this.login = "studsignup";
  }

  studlogin() {
    this.login = "studlogin";
  }

}
