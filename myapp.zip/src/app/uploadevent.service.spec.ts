import { TestBed } from '@angular/core/testing';

import { UploadeventService } from './uploadevent.service';

describe('UploadeventService', () => {
  let service: UploadeventService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UploadeventService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
