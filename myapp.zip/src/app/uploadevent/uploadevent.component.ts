import { Component, OnInit } from '@angular/core';
import { UploadeventService } from '../uploadevent.service';

@Component({
  selector: 'app-uploadevent',
  templateUrl: './uploadevent.component.html',
  styleUrls: ['./uploadevent.component.css']
})

export class UploadeventComponent implements OnInit {

  types: Array<Object> = [
    {id: 0, name: "Hackathon"},
    {id: 1, name: "Workshop"},
    {id: 2, name: "Quiz"},
    {id: 3, name: "Build-A-Thon"},
    {id: 4, name: "Web-A-Thon"},
    {id: 5, name: "Training Program"},
    {id: 6, name: "Coding Contest"}
  ]

  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  orgId: any;
  eType: any;
  eventType: string;
  
  constructor(private service: UploadeventService) {
    this.imageUrl = '/assets/img/logo3.png';
  }

  ngOnInit() {
    this.orgId = localStorage.getItem("orgId");
    console.log(this.orgId);

    // this.eventType = this.types[1].name;
    // console.log("Type: ", this.eventType);
  }

  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
    console.log(imageForm);
    console.log("Etype:", this.eType);

    // this.eventType = this.types[this.eType].name;
    console.log("Type: ", this.eventType);

    this.service.postFile(imageForm, this.eventType, this.orgId, this.fileToUpload).subscribe(
      data => {
        console.log('done');
        window.alert("Uploaded!!");
        // this.imageUrl = '/assets/img/home.jpg';
      });
    }

  onTypeSelected(val: any) {
    console.log("val", val);
    if (val == 0) {
      this.eventType = "Hackathon";
    }
    if (val == 1) {
      this.eventType = "Workshop";
    }
    if (val == 2) {
      this.eventType = "Quiz";
    }
    if (val == 3) {
      this.eventType = "Build-A-Thon";
    }
    if (val == 4) {
      this.eventType = "Web-A-Thon";
    }
    if (val == 5) {
      this.eventType = "Training Program";
    }
    if (val == 6) {
      this.eventType = "Coding Contest";
    }
  }
   
} 