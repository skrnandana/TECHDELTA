import { Component, OnInit } from '@angular/core';
import { OrgServiceService } from './../org-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-organizer-register',
  templateUrl: './organizer-register.component.html',
  styleUrls: ['./organizer-register.component.css']
})
export class OrganizerRegisterComponent implements OnInit {


  organizer : any;
  gender: string = '';
  genders: any = [
    'Male',
    'Female'
  ]

  radioChangeHandler(event: any) {
    this.gender = event.target.value;
  }

  constructor(private router: Router,private service: OrgServiceService) {
    this.organizer={organizerName:'',gender:'',email:'',organizerInstitute:'',password:''};
   }

  ngOnInit(): void {
  }

  
  registerOrganizer(): void {
    this.service.registerOrganizer(this.organizer).subscribe((result: any) => {
       console.log(result); 
      }); 
       this.router.navigate(['loginO']);
    console.log(this.organizer);
    console.log("email", this.organizer.email);
    this.service.sendMail(this.organizer.email).subscribe();
  }
}
