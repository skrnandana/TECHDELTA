import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-studentlogin',
  templateUrl: './studentlogin.component.html',
  styleUrls: ['./studentlogin.component.css']
})
export class StudentloginComponent implements OnInit {
  title = 'Tech Delta';
  
  @ViewChild('loginRef', {static: true }) loginElement: ElementRef;
  show: boolean;
  //auth2: gapi.auth2.GoogleAuth;
  Name: any;
  auth2: gapi.auth2.GoogleAuth;

  user: any;
  student: any;
  emailId: any;

  constructor(private router:Router, private service: StudentService) {
    this.user = {loginId: '', password: ''};
  }

  ngOnInit() {
    this.googleInitialize();
  }

  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '631867203803-gfnbuj33563dmuorhmfm6cv2prqasulq.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        this.show = true;
        this.Name =  profile.getName();
        console.log(this.Name)
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
        this.router.navigate(['upload']);
      }, (error) => {
        // alert(JSON.stringify(error, undefined, 2));
      });     
  }

  loginSubmit(loginForm: any): void {
    this.emailId = loginForm['loginId'];
    this.service.getStudentbyEmail(this.emailId).subscribe((result: any) => { 
      console.log("Result", result);
      this.student = result; 
      if (loginForm['password'] == result['password']) {
        // alert("Welcome");
        this.router.navigate(['']);
        this.service.setUserLoggedIn();
      }
      else {
        alert("Invalid Credentials..")
      }
    });

    console.log(loginForm);
  }

  studsignup() {
    this.router.navigate(['signupS']);
  }
  
}
