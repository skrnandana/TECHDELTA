// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class UploadeventService {

//   constructor(private httpClient: HttpClient) { }


//  postFile(ImageForm: any, orgId: any, fileToUpload: File) {
//   // const endpoint='RESTAPI/webapi/myresource/';
//   const formData: FormData = new FormData();
//   formData.append('eventName', ImageForm.eventName);
//   formData.append('eventDescription', ImageForm.eventDescription);
//   formData.append('eventImage', fileToUpload, fileToUpload.name);
//   formData.append('organizerId', orgId);

//   return this.httpClient.post('RESTAPI_TechDelta/webapi/myresource/uploadImage', formData);
// }
// }



import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UploadeventService {

  constructor(private httpClient: HttpClient) { }

 postFile(ImageForm: any, eventType: string, orgId: any, fileToUpload: File) {
  // const endpoint='RESTAPI/webapi/myresource/';
  console.log(eventType);
  const formData: FormData = new FormData();
  formData.append('eventName', ImageForm.eventName);
  formData.append('eventDescription', ImageForm.eventDescription);
  formData.append('eventType', eventType);
  formData.append('eventDuration', ImageForm.eventDuration);
  formData.append('startDate', ImageForm.startDate);
  formData.append('endDate', ImageForm.endDate);
  formData.append('eventImage', fileToUpload, fileToUpload.name);
  formData.append('organizerId', orgId);

  return this.httpClient.post('RESTAPI_TechDelta/webapi/myresource/uploadImage',formData);
}
}

