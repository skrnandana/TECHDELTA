import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OrgServiceService {

  isOrganizerLogged: boolean;
  constructor(private httpClient: HttpClient) {
    this.isOrganizerLogged = false;
   }
	setOrganizerLoggedIn(): any { // login success
	 this.isOrganizerLogged = true;
	}
	getOrganizerLogged(): any {
		return this.isOrganizerLogged;
	}
	setorgLoggedOut(): any {
		this.isOrganizerLogged = false;
	}

getOrganizerByEmail(email: any) {
 return this.httpClient.get('RESTAPI_TechDelta/webapi/myresource/getOrganizerByEmail/' +email);
}

registerOrganizer(organizer: any) {
console.log(organizer);
 return this.httpClient.post('RESTAPI_TechDelta/webapi/myresource/registerOrganizer/', organizer);
}

sendMail(email: any): any {
	return this.httpClient.get('RESTAPI_TechDelta/webapi/myresource/mail/' +email);
}

}
