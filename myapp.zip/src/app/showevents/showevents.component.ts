import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-showevents',
  templateUrl: './showevents.component.html',
  styleUrls: ['./showevents.component.css']
})
export class ShoweventsComponent implements OnInit {

  constructor(private studservice: StudentService) { }
  events: any;
  searchText: string;

  ngOnInit(): void {
    this.studservice.getEvents().subscribe((result: any) => { 
      console.log(result);
      this.events = result;
    });
    console.log("Events", this.events);
  }

  addToFavorites(event: any) {
    this.studservice.addToFavorites(event);
  }
  addToEnroll(event: any) {
    this.studservice.addToEnroll(event);
  }

}
