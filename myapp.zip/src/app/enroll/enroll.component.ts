import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-enroll',
  templateUrl: './enroll.component.html',
  styleUrls: ['./enroll.component.css']
})
export class EnrollComponent implements OnInit {

  

enrollItems = [];
retrieveData: any;
events: any;
eventDetails: any;
searchText: String;

constructor(private studservice: StudentService) { 
  this.enrollItems = this.studservice.enrollItems;
}

ngOnInit(): void {
  this.events = {};
  this.eventDetails = {event: {}};
}

purchase(event: any) {
  this.studservice.purchase(event).subscribe();
}

}

