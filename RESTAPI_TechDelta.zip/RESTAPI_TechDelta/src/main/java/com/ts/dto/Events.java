package com.ts.dto;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import com.ts.dto.Organizers;
import com.ts.dto.Enroll;




@XmlRootElement
@Entity
public class Events{
	
	@Id@GeneratedValue
	private int eventId;
	private String eventDescription;
	private String eventName;
	private String eventImage;
	private String startDate;
	private String endDate;
	private String eventDuration;
	private String eventType;

	
	@JsonIgnore
	@OneToMany(mappedBy="event",fetch = FetchType.LAZY)
	private Set<Enroll> enrollList =new HashSet<Enroll>();
	
	@ManyToOne
	@JoinColumn(name="organizerId")
	private Organizers organizer;
		
	public Events() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getEventDuration() {
		return eventDuration;
	}
	public void setEventDuration(String eventDuration) {
		this.eventDuration = eventDuration;
	}
	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	

	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}
	public String getEventDescription() {
		return eventDescription;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}	
	public void setEventImage(String eventImage) {
		this.eventImage = eventImage;
	}
	public String getEventImage() {
		return eventImage;
	}
	public Set<Enroll> getEnrollList() {
		return enrollList;
	}
	public void setEnrollList(Set<Enroll> enrollList) {
		this.enrollList = enrollList;
	}
	public Organizers getOrganizer() {
		return organizer;
	}
	public void setOrganizer(Organizers organizer) {
		this.organizer = organizer;
	}
	
}